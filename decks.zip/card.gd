class_name Card
extends Control

@onready var color_rect: ColorRect = $ColorRect
@onready var count_label: Label = $CountLabel
@onready var name_label: Label = %NameLabel
@onready var state_machine: Node = $CardStateMachine
@onready var drop_point_detector: Area2D = $DropPointDetector
@onready var card_detector: Area2D = $CardsDetector

var home_field: Field
var card_data: Dictionary = {}
var alt_textures: Array[Texture2D] = []
var current_alt_index := 0
var index: int = 0

func _ready():
	custom_minimum_size = Vector2(75, 125)
	update_texture()

func setup(data: Dictionary, field: Field):
	card_data = data.duplicate(true)
	home_field = field

	var card_code := card_data.get("card_code", "")
	current_alt_index = AltArtManager.get_alt_index(card_code)

	DeckManager.assign_card_image_path(card_data)
	alt_textures.clear()

	var base_tex = load_texture(card_data.get("image_path", ""))
	if base_tex:
		alt_textures.append(base_tex)

	var set_code := card_data.get("set_code", "")
	var i := 1
	while true:
		var alt_path := "res://assets/cards/Alts/%s/%s_alt%d.png" % [set_code, card_code, i]
		if ResourceLoader.exists(alt_path):
			var alt_tex = ResourceLoader.load(alt_path, "Texture2D")
			if alt_tex is Texture2D:
				alt_textures.append(alt_tex)
			i += 1
		else:
			break

	update_texture()

	# Show count label only for main/don grids, hide in search grid
	var zone = card_data.get("zone", "")
	count_label.text = zone != "search" ? "x%d" % card_data.get("count", 1) : ""

func update_texture():
	var card_texture = get_node_or_null("CardImage")
	if card_texture and alt_textures.size() > current_alt_index:
		var tex: Texture2D = alt_textures[current_alt_index]
		if card_texture is TextureButton:
			card_texture.texture_normal = tex
		elif "texture" in card_texture:
			card_texture.texture = tex

func get_card_data() -> Dictionary:
	var data = card_data.duplicate(true)
	data["alt_index"] = current_alt_index
	return data
