extends Node

@export_node_path var field_path: NodePath
@export_node_path var search_grid_path: NodePath
@export_node_path var main_deck_grid_path: NodePath
@export_node_path var don_deck_grid_path: NodePath

@onready var field_node = get_node(field_path)
@onready var search_grid = get_node(search_grid_path)
@onready var main_deck_grid = get_node(main_deck_grid_path)
@onready var don_deck_grid = get_node(don_deck_grid_path)

@onready var deck_dropdown = $HeaderBar/DeckDropdown
@onready var rename_button = $HeaderBar/RenameButton
@onready var save_button = $HeaderBar/SaveDeckButton
@onready var delete_button = $HeaderBar/DeleteButton
@onready var export_button = $HeaderBar/ExportButton
@onready var clear_main_button = $HeaderBar/ClearMainDeckButton
@onready var clear_don_button = $HeaderBar/ClearDonDeckButton

const SAVE_DIR = "user://decks/"
const EXPORT_PATH = "user://deck_export"
var current_deck_name := "ST01"

func _ready():
	DirAccess.make_dir_absolute(SAVE_DIR)
	_load_deck_list()

	deck_dropdown.item_selected.connect(_on_deck_selected)
	rename_button.pressed.connect(_on_rename_deck)
	save_button.pressed.connect(_on_save_pressed)
	delete_button.pressed.connect(_on_delete_deck)
	export_button.pressed.connect(_on_export_pressed)
	clear_main_button.pressed.connect(_on_clear_main_deck)
	clear_don_button.pressed.connect(_on_clear_don_deck)

	load_search_cards()
	self.load_main_deck(current_deck_name)
	load_don_deck("Don")

func _on_deck_selected(index):
	current_deck_name = deck_dropdown.get_item_text(index)
	DeckManager.load_main_deck(current_deck_name)

func _on_rename_deck():
	var new_name = "RenamedDeck" + str(Time.get_ticks_msec())
	var old_path = SAVE_DIR + current_deck_name + ".json"
	var new_path = SAVE_DIR + new_name + ".json"

	if FileAccess.file_exists(old_path):
		DirAccess.rename_absolute(old_path, new_path)
		current_deck_name = new_name
		_load_deck_list()
		print("📛 Renamed deck to ", new_name)

func _on_delete_deck():
	var path = SAVE_DIR + current_deck_name + ".json"
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)
		current_deck_name = ""
		_load_deck_list()
		clear_grid(main_deck_grid)
		print("🗑️ Deleted deck: ", path)

func _on_save_pressed():
	var data = {
		"main": _extract_grid_data(main_deck_grid),
		"don": _extract_grid_data(don_deck_grid),
	}
	var path = SAVE_DIR + current_deck_name + ".json"
	var file = FileAccess.open(path, FileAccess.WRITE)
	file.store_string(JSON.stringify(data, "\t"))
	file.close()
	print("💾 Saved deck to ", path)

func _on_export_pressed():
	var data = {
		"main": _extract_grid_data(main_deck_grid),
		"don": _extract_grid_data(don_deck_grid),
	}

	# Export JSON
	var json_file = FileAccess.open(EXPORT_PATH + ".json", FileAccess.WRITE)
	json_file.store_string(JSON.stringify(data, "\t"))
	json_file.close()

	# Export TXT
	var txt = ""
	for card in data.main:
		txt += "%s x%s\n" % [card["card_code"], card.get("count", 1)]
	var txt_file = FileAccess.open(EXPORT_PATH + ".txt", FileAccess.WRITE)
	txt_file.store_string(txt)
	txt_file.close()

	# Export CSV
	var csv = "CardCode,Count\n"
	for card in data.main:
		csv += "%s,%s\n" % [card["card_code"], card.get("count", 1)]
	var csv_file = FileAccess.open(EXPORT_PATH + ".csv", FileAccess.WRITE)
	csv_file.store_string(csv)
	csv_file.close()

	print("📤 Exported deck in .json, .txt, .csv to ", EXPORT_PATH)

func _on_clear_main_deck():
	clear_grid(main_deck_grid)

func _on_clear_don_deck():
	clear_grid(don_deck_grid)

func clear_grid(grid: Node):
	for child in grid.get_children():
		child.queue_free()

func _extract_grid_data(grid: Node) -> Array:
	var cards_data = []
	for card in grid.get_children():
		if card.has_method("get_card_data"):
			cards_data.append(card.get_card_data())
	return cards_data

func _load_deck_list():
	deck_dropdown.clear()
	var dir = DirAccess.open(SAVE_DIR)
	if dir:
		for f in dir.get_files():
			if f.ends_with(".json"):
				deck_dropdown.add_item(f.get_basename())

func load_search_cards():
	clear_grid(search_grid)

	var path = "res://assets/JSON/cards.json"
	var data = DeckManager.load_json(path)

	if typeof(data) != TYPE_ARRAY:
		push_error("cards.json must be an array!")
		return

	var shown_cards := {}

	for card_data in data:
		if typeof(card_data) != TYPE_DICTIONARY:
			continue

		var card_code = card_data.get("card_code", "")
		if shown_cards.has(card_code):
			continue
		shown_cards[card_code] = true

		var cards = DeckManager.create_card(card_data, field_node)
		for card in cards:
			search_grid.add_child(card)

func load_main_deck(deck_name: String):
	clear_grid(main_deck_grid)
	var path = SAVE_DIR + deck_name + ".json"
	var data = DeckManager.load_json(path)

	if typeof(data) != TYPE_DICTIONARY or not data.has("main"):
		push_error("Deck JSON must have 'main' section")
		return

	for card_data in data["main"]:
		if typeof(card_data) == TYPE_DICTIONARY:
			var cards = DeckManager.create_card(card_data, field_node)
			for card in cards:
				main_deck_grid.add_child(card)
				
func load_don_deck(don_name: String):
	clear_grid(don_deck_grid)
	var path = SAVE_DIR + don_name + ".json"
	var data = DeckManager.load_json(path)

	if typeof(data) != TYPE_DICTIONARY or not data.has("don"):
		push_error("Deck JSON must have 'don' section")
		return

	for card_data in data["don"]:
		if typeof(card_data) == TYPE_DICTIONARY:
			var cards = DeckManager.create_card(card_data, field_node)
			for card in cards:
				don_deck_grid.add_child(card)
