class_name Card
extends Control

## --- FROM SMART ADDON ---
@onready var color_rect: ColorRect = $ColorRect
@onready var label: Label = $Label
@onready var name_label: Label = %NameLabel
@onready var state_machine: Node = $CardStateMachine
@onready var drop_point_detector: Area2D = $DropPointDetector
@onready var card_detector: Area2D = $CardsDetector
@onready var home_field: Field

var index: int = 0

func _ready():
	name_label.text = name
	update_texture()


func _input(event):
	state_machine.on_input(event)

func _on_gui_input(event):
	state_machine.on_gui_input(event)

func _on_mouse_entered():
	state_machine.on_mouse_entered()

func _on_mouse_exited():
	state_machine.on_mouse_exited()


## --- YOUR CARD DATA & TEXTURE LOGIC ---
var card_data: Dictionary = {}
var alt_textures: Array[Texture2D] = []
var current_alt_index := 0

func setup(data: Dictionary, zone: String = ""):
	card_data = data.duplicate(true)
	card_data["zone"] = zone

	var card_code := card_data.get("card_code", "")
	current_alt_index = AltArtManager.get_alt_index(card_code)

	DeckManager.assign_card_image_path(card_data)

	# Load base texture
	alt_textures.clear()
	var base_tex = load_texture(card_data.get("image_path", ""))
	if base_tex:
		alt_textures.append(base_tex)

	# Load alternate textures
	var set_code := card_data.get("set_code", "")
	var i := 1
	while true:
		var alt_path := "res://assets/cards/Alts/%s/%s_alt%d.png" % [set_code, card_code, i]
		if ResourceLoader.exists(alt_path):
			var alt_tex = ResourceLoader.load(alt_path, "Texture2D")
			if alt_tex is Texture2D:
				alt_textures.append(alt_tex)
			i += 1
		else:
			break

	update_texture()

func update_texture():
	var card_texture = get_node_or_null("CardImage")  # Make sure "CardImage" exists
	if card_texture and alt_textures.size() > current_alt_index:
		var tex: Texture2D = alt_textures[current_alt_index]
		if card_texture is TextureButton:
			card_texture.texture_normal = tex
		elif "texture" in card_texture:
			card_texture.texture = tex

func next_alt():
	current_alt_index = (current_alt_index + 1) % alt_textures.size()
	AltArtManager.set_alt_index(card_data.get("card_code", ""), current_alt_index)
	update_texture()

func prev_alt():
	current_alt_index = (current_alt_index - 1 + alt_textures.size()) % alt_textures.size()
	AltArtManager.set_alt_index(card_data.get("card_code", ""), current_alt_index)
	update_texture()

func get_card_data() -> Dictionary:
	var data := card_data.duplicate(true)
	data["alt_index"] = current_alt_index
	return data

func load_texture(path: String) -> Texture2D:
	if path.strip_edges() == "" or not ResourceLoader.exists(path):
		return load_fallback_texture()
	var tex = ResourceLoader.load(path, "Texture2D")
	if tex == null or not tex is Texture2D:
		return load_fallback_texture()
	return tex

func load_fallback_texture() -> Texture2D:
	return preload("res://assets/cards/Base/BaseCard.png")
