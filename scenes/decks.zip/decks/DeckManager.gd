extends Node

var card_scene: PackedScene = preload("res://scenes/cards/card.tscn")
var cards_data: Array = []

func _ready():
	print("✅ DeckManager autoload initialized")

# ✅ Load and parse JSON (cards or deck files)
func load_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		push_error("JSON not found: %s" % path)
		return null

	var file = FileAccess.open(path, FileAccess.READ)
	if file == null:
		push_error("Couldn't open file: %s" % path)
		return null

	var json_str = file.get_as_text()
	var result = JSON.parse_string(json_str)
	if result == null:
		push_error("Failed to parse JSON: %s" % path)
	return result

# Spawn a card instance and setup data
func create_card(card_data: Dictionary, zone: String = "") -> Array:
	var results := []

	if card_scene == null:
		push_error("Card.tscn scene not found.")
		return results

	var count := card_data.get("count", 1)
	for i in range(count):
		var card = card_scene.instantiate()
		card.setup(card_data.duplicate(true), zone)  # true = deep copy
		results.append(card)

	return results

# Assign image path using standard sets (not alt arts for now)
func assign_card_image_path(card_data: Dictionary) -> void:
	var set_code = card_data.get("set_code", "")
	var card_code = card_data.get("card_code", "")
	var card_type = card_data.get("type", "")

	if card_type == "DON!!":
		card_data["image_path"] = "res://assets/cards/Don/Don.png"
		return

	if card_code == "" or set_code == "":
		card_data["image_path"] = "res://assets/cards/Base/BaseCard.png"
		return

	card_data["image_path"] = "res://assets/cards/%s/%s.png" % [set_code, card_code]

	# Check if the image exists, fallback if not
	if not ResourceLoader.exists(card_data["image_path"]):
		push_warning("Missing image for %s, using fallback." % card_code)
		card_data["image_path"] = "res://assets/cards/Base/BaseCard.png"
