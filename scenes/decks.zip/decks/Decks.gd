extends Node

@export_node_path var search_grid_path: NodePath
@export_node_path var main_deck_grid_path: NodePath
@export_node_path var don_deck_grid_path: NodePath

@onready var search_grid = get_node(search_grid_path)
@onready var main_deck_grid = get_node(main_deck_grid_path)
@onready var don_deck_grid = get_node(don_deck_grid_path)

const JSON_PATH = "res://assets/JSON/"

func _ready():
	print("Decks.gd ready")
	load_search_cards()
	load_main_deck("ST01")
	load_don_deck("Don")


func load_search_cards():
	clear_grid(search_grid)
	var path = JSON_PATH + "cards.json"
	var data = DeckManager.load_json(path)
	if typeof(data) != TYPE_ARRAY:
		push_error("cards.json must be an array!")
		return

	for card_data in data:
		if typeof(card_data) == TYPE_DICTIONARY:
			var cards = DeckManager.create_card(card_data, "search")
			for card in cards:
				search_grid.add_child(card)


func load_main_deck(file: String):
	clear_grid(main_deck_grid)
	var path = JSON_PATH + "%s.json" % file
	var deck = DeckManager.load_json(path)

	if typeof(deck) != TYPE_DICTIONARY or not deck.has("main"):
		push_error("Deck JSON must have 'main' section: %s" % file)
		return

	for card_data in deck["main"]:
		if typeof(card_data) == TYPE_DICTIONARY:
			var cards = DeckManager.create_card(card_data, "main")
			for card in cards:
				main_deck_grid.add_child(card)


func load_don_deck(file: String):
	clear_grid(don_deck_grid)
	var path = JSON_PATH + "%s.json" % file
	var deck = DeckManager.load_json(path)

	if typeof(deck) != TYPE_DICTIONARY or not deck.has("don"):
		push_error("Don deck must have 'don' section: %s" % file)
		return

	for card_data in deck["don"]:
		if typeof(card_data) == TYPE_DICTIONARY:
			var cards = DeckManager.create_card(card_data, "don")
			for card in cards:
				don_deck_grid.add_child(card)


func clear_grid(grid: Node):
	for child in grid.get_children():
		child.queue_free()
