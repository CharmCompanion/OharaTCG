extends Node

func sanitize_card_data(data: Dictionary) -> Dictionary:
	data["count"] = data.get("count", 1)
	data["alt_index"] = data.get("alt_index", 0)
	return data
